﻿_readME.txt

---------------------------------------------------
-------Projet pour le cours "Design de SIG" -------
---------Par Benoît CORDAY et René LUGRIN ---------
---------------------------------------------------
-------Explications pour démarrer le projet -------
---------------------------------------------------

1. BASE DE DONNEES

- Restorer la base de données "burkina" qui 
  est en annexe
- Démarrer un serveur mongo 
  (commande "mongod" dans un nouveau terminal)

2. SERVEUR NODE.JS

- Ouvrir un nouveau terminal
- Se placer dans le dossier "BFwebSIG_v1"
- Exécuter la commande "npm start"
- Le programme doit signaler qu'il a bien réussi 
  à se connecter à la base de données

3. UTILISER LE WEBSIG

- Ouvrir un navigateur, de préférence 
  Firefox ou Chrome (pas testé sur les autres)
- Aller à l'adresse http://localhost:3000/
- Vous êtes sur notre page d'accueil et 
  vous pouvez ensuite naviguer dans notre projet 